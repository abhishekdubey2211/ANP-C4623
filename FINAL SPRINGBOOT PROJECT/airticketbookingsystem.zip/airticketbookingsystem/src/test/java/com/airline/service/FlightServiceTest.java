package com.airline.service;


import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Flight;
import com.airline.model.FlightDTO;
import com.airline.repository.FlightRepository;
import com.airline.util.FlightConverter;

@SpringBootTest
class FlightServiceTest {

	@Autowired
	private FlightService flightService;
	
	@MockBean
	private FlightRepository flightRepository;
	
	@Autowired
	FlightConverter flightConverter;
	
//	@Test
//	void addFlightTest()
//	{
//		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
//				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
//				destination("bangalore").travellerClass("business").build();
//		
//		Mockito.when(flightRepository.save(flight)).thenReturn(flight);
//		FlightDTO dto = flightConverter.convertToFlightDTO(flight); 
//		assertEquals(dto.getFlightId(), flight.getFlightId());
//	}
	
//	@Test
//	void deleteFlightByIdTest()
//	{
//		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
//				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
//				destination("bangalore").travellerClass("business").build();
//		
//		Optional<Flight> opf= Optional.of(flight);
//		Mockito.when(flightRepository.findById(opf.get().getFlightId())).thenReturn(opf);
//		
//		assertThat(flightService.deleteFlightById(opf.get().getFlightId())).isEqualTo("Flight record deleted successfully!!");
//		
//	}
	
	@Test
	@DisplayName("Negative Test Case")
	void updateFlight()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
				destination("bangalore").travellerClass("business").build();
		
		Optional<Flight> opfli= Optional.of(flight);
		Mockito.when(flightRepository.findById(flight.getFlightId())).thenReturn(opfli);
		Flight p=opfli.get();
		flight.setAvailableSeats(10);
		
		Mockito.when(flightRepository.save(flight)).thenReturn(p);
		 
		 FlightDTO dto=flightService.updateFlight(flight.getFlightId(), flight);
		assertEquals(dto.getAvailableSeats(), 5);
	}

}
