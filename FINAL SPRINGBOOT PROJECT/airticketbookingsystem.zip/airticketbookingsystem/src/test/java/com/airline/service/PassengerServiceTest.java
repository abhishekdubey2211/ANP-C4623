package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.util.Converter;

@SpringBootTest
class PassengerServiceTest {

	@Autowired
	private PassengerService passengerService;
	
	@Autowired
	private Converter converter;
	
	@MockBean
	private PassengerRepository passengerRepository;
	
	//this method will test the savePassenger method
//	@Test
//	void testCreatePassenger()
//	{
//		Passenger passenger = Passenger.builder().name("pallab").email("pal@gmail.com").
//				phno("9812764509").userName("pallab").password("pal123").role("user").build();
//		
//		Mockito.when(passengerRepository.save(passenger)).thenReturn(passenger);
//		assertThat(passengerService.createPassenger(passenger)).isEqualTo("Passenger saved successfully!!");
//	}
	
//	@Test
//	void testGetAllPassenger()
//	{
//		Passenger passenger1 = Passenger.builder().name("pallab").email("pal@gmail.com").
//				phno("9812764509").userName("pallab").password("pal123").role("user").build();
//		Passenger passenger2 = Passenger.builder().name("chandan").email("cha@gmail.com").
//				phno("9731209456").userName("chandan").password("c123").role("user").build();
//		
//		List<Passenger> list = new ArrayList<>();
//		list.add(passenger1);
//		list.add(passenger2);
//		
//		Mockito.when(passengerRepository.findAll()).thenReturn(list);
//		
//		List<PassengerDTO> dto = passengerService.getAllPassenger();
//		
//		List<Passenger> pass= new ArrayList<Passenger>();
//		dto.forEach(passDto->
//		{
//			pass.add(converter.convertToPassengerEntity(passDto));
//		});
//		
//		assertThat(pass).isEqualTo(list);
//	}
	
	//@Test
//	void testDeletePassenger()
//	{
//		Passenger pass = Passenger.builder().name("chandan").email("cha@gmail.com").
//				phno("9731209456").userName("chandan").password("c123").role("user").build();
//		
//		Optional<Passenger> opPass= Optional.of(pass);
//		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
//		
//		assertThat(passengerService.deletePassengerById(opPass.get().getId())).
//		isEqualTo("Record deleted successfully");
//	}
	
	
	@Test
	@DisplayName("Negative Test Case")
	void testNegativeGetPassengerById()
	{
		Passenger pass = Passenger.builder().name("chandan").email("cha@gmail.com").
				phno("9731209456").userName("chandan").password("c123").role("user").build();
		
		Optional<Passenger> opPass= Optional.of(pass);
	   Mockito.when(passengerRepository.findById(pass.getId())).thenReturn(opPass);
	   
	   PassengerDTO pDto = converter.convertToPassengerDTO(pass);
	   assertThat(passengerService.getPassengerById(pass.getId())).isEqualTo(pDto);
	
	}
	
	
	@Test
	void testUpdatePassenger()
	{
		Passenger passenger = Passenger.builder().name("chandan").email("cha@gmail.com").
				phno("9731209456").userName("chandan").password("c123").role("user").build();
	
		Optional<Passenger> opPass1= Optional.of(passenger);
		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass1);
		Passenger p=opPass1.get();
		passenger.setName("pallab");;
		
		Mockito.when(passengerRepository.save(passenger)).thenReturn(p);
		 
		 PassengerDTO dto=passengerService.updatePassenger(passenger.getId(), passenger);
		assertEquals(dto.getName(), p.getName());
	}
}
