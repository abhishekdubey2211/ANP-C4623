package com.moviebs.service;
import java.util.*;

import com.moviebs.model.*;
public interface AmountService
{
	
	float getTicketAmount(List<Ticket> TicketList);
}