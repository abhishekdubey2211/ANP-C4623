package bloodbank.dao;

import java.util.List;

import bloodbank.model.Bloodbank;

public interface IbloodbankDao {

	void save(Bloodbank bloodbank);

//	void update(Bloodbank bloodbank);
//
//	Bloodbank getById(int id);
//
//	void delete(int id);
//
//	List<Bloodbank> getAll();

}