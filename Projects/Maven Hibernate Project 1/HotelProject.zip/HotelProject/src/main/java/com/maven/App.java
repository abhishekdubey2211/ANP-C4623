package com.maven;

import java.util.*;
import com.maven.dao.*;
import com.maven.model.*;
public class App 
{
    public static void main( String[] args )
    {
    	HotelDao hotelDao = new HotelDao();

        //GATHERING EMPLOYEES DATA
        Hotel hotel =new Hotel("Royals Hotel",001,"Abhishek Dubey","abhi@gmail.com",885001499);
        Hotel hotel1 =new Hotel("Royals Hotel",002,"SACHIN YADAV","sachin@gmail.com",74851499);
        Hotel hotel2 =new Hotel("Royals Hotel",003,"ANJU PRAJAPATI","anju@gmail.com",775001499);
        Hotel hotel3 =new Hotel("Royals Hotel",004,"AMIT Dubey","amit@gmail.com",885521499);
        
        //passing value in parameterized constructor     FOR SAVING EMPLOYEES DATA
        hotelDao.saveHotel(hotel);
        hotelDao.saveHotel(hotel1);
        hotelDao.saveHotel(hotel2);
        hotelDao.saveHotel(hotel3);
        
        
        // test updateHotel
        hotel.setGuestname("ABHISHEK");
        hotelDao.updateHotel(hotel);
        
        // test getHotelById
//        Hotel hotel4 = hotelDao.getHotelById(hotel.getId());

        
        // test getAllHotels
        List < Hotel > hotels = hotelDao.getAllHotels();
        hotels.forEach(hotel4 -> System.out.println(hotel4.getId()));
        // -> lambda expression left side of arrow:parameter ; right:value
        
        // test deleteHotel
//        hotelDao.deleteHotel(2);

    }
 }



